import { TestBed, inject } from '@angular/core/testing';

import { SuccessAlertComponent } from './SuccessAlert.component';

describe('a SuccessAlert component', () => {
	let component: SuccessAlertComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				SuccessAlertComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([SuccessAlertComponent], (SuccessAlertComponent) => {
		component = SuccessAlertComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});