import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'SuccessAlert',
	templateUrl: 'SuccessAlert.component.html',
	styleUrls:['./SuccessAlert.component.scss']
})

export class SuccessAlertComponent implements OnInit {

	ngOnInit() { }
}