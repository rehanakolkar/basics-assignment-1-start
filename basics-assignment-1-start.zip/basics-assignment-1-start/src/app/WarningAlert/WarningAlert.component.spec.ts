import { TestBed, inject } from '@angular/core/testing';

import { WarningAlertComponent } from './WarningAlert.component';

describe('a WarningAlert component', () => {
	let component: WarningAlertComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				WarningAlertComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([WarningAlertComponent], (WarningAlertComponent) => {
		component = WarningAlertComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});