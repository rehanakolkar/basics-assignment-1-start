import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'WarningAlert',
	templateUrl: 'WarningAlert.component.html',
	styleUrls:['./WarningAlert.component.scss']
})

export class WarningAlertComponent implements OnInit {

	ngOnInit() { }
}